

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<form method="GET" action="controle.php">
		<p><input type="text" name="cpf" placeholder="CPF"></p>
		<p><input type="text" name="nome" placeholder="NOME"></p>
		<p><input type="text" name="telefone" placeholder="TELEFONE"></p>
		<p><input type="submit" value="Cadastrar" name="botao"></p>
		<p><input type="submit" value="Buscar" name="botao"></p>
		<p><input type="submit" value="Atualizar" name="botao"></p>
		<p><input type="submit" value="Apagar" name="botao"></p>
	</form>
</body>
</html>